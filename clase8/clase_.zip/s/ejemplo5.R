library(shiny)
library(ggplot2)
library(learningtower)

ui <- fluidPage(
  uiOutput("dynamic_title"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId = 'columna', label = 'Seleccioná una columna:',
                  choices = c("math", "read", "science"),
                  selected = 'math'),
      radioButtons("radio", label = h3("Seleccioná los años"),
                   choices = c(2000, 2003, 2006, 2009, 2012, 2015, 2018), 
                   selected = 2018)
    ),
    
    mainPanel(
      plotOutput("plot")
    )
  )
)

server <- function(input, output, session) {
  
  output$dynamic_title <- renderUI({
    titlePanel(paste0("Resultados PISA ", input$radio))
  })
  
  datos_filtrados <- reactive({
    # Construir el nombre del conjunto de datos
    col <- paste0("student_subset_", input$radio)
    
    # Cargar los datos
    data(list = col, package = "learningtower")
    
    # Obtener el conjunto de datos cargado
    student_subset_all <- get(col)
    
    # Filtrar datos para Argentina
    data_anio_filtrado_arg <- student_subset_all[student_subset_all$country == "ARG",]
    
    return(data_anio_filtrado_arg)
  })
  
  output$plot <- renderPlot({        
    ggplot(datos_filtrados(), aes(x = wealth, y = .data[[input$columna]])) +
      geom_point() +
      theme_bw()
  })
}

shinyApp(ui, server)