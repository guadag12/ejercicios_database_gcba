library(shiny)

ui <- fluidPage(
  
  titlePanel("El título de mi primer app acá!"),
  
  sidebarLayout(
    sidebarPanel(
      fluidRow(h1('Side Bar Panel acá!'))
    ),
    
    mainPanel(
      fluidRow(h2("Todo esto es Main Panel!"))
    )
  )
)

server <- function(input, output) {
  
}

shinyApp(ui = ui, server = server)