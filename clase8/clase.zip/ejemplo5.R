library(shiny)
library(learningtower)
library(ggplot2)
student_subset_all= data(student_subset_2015)

student_subset_2018_ARG <- student_subset_2018[student_subset_2018$country == "ARG",]

ui <- fluidPage(
  titlePanel(paste0("Resultados PISA", input$radio)),
  
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId = 'columna', label = 'Seleccioná una columna:',
                  choices = c("math", "read","science"),
                  selected = 'math'),
      radioButtons("radio", label = h3("Seleccioná los años"),
                   choices = c(2000, 2003, 2006, 2009, 2012, 2015, 2018), 
                   selected = 2018),
      
    ),
    
    mainPanel(
      plotOutput("plot")
    )
  )
)


server <- function(input, output, session) {
  
  datos_filtrados <- reactive({
    # Construir el nombre del conjunto de datos
    col <- paste0("student_subset_", input$radio)
    
    # Cargar los datos
    data(list = col, package = "learningtower")
    
    # Obtener el conjunto de datos cargado
    student_subset_all <- get(col)
    
    # Filtrar datos para Argentina
    data_anio_filtrado_arg <- student_subset_all[student_subset_all$country == "ARG",]
    
    return(data_anio_filtrado_arg)

  })
  
  
  output$plot <- renderPlot({        
    ggplot(datos_filtrados(), aes(x = wealth, y = .data[[input$columna]])) +
      geom_point() +
      theme_bw()
  })
  
  
}

shinyApp(ui, server)