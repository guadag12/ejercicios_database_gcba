library(shiny)
library(learningtower)
library(ggplot2)

data(student_subset_2018)

student_subset_2018_ARG <- student_subset_2018[student_subset_2018$country == "ARG",]

ui <- fluidPage(
  titlePanel("Resultados PISA 2018"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId = 'columna', label = 'Seleccioná una columna:',
                  choices = c("math", "read","science"),
                  selected = 'math')
      ),
    
    mainPanel(
      plotOutput("plot")
    )
  )
  )


server <- function(input, output, session) {
  output$plot <- renderPlot({        
    ggplot(student_subset_2018_ARG, aes(x = wealth, y = .data[[input$columna]])) +
      geom_point() +
      theme_bw()
  })
}

shinyApp(ui, server)