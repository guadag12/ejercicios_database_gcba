library(gapminder)
library(shiny)
library(ggplot2)
library(shinythemes)
df <- gapminder

ui <- fluidPage(
  theme = shinytheme("flatly"),
  navbarPage("ANALISIS DE POBLACION",
             tabPanel("Plot",
                      sidebarLayout(
                        sidebarPanel(
                          radioButtons(inputId = 'input_continente', 
                                       label = h6("Seleccioná el continente:"), 
                                       choices = unique(df$continent),
                                       selected = unique(df$continent)[1]
                          ),
                          sliderInput(inputId = 'input_fecha',
                                      label = h1("Seleccioná la fecha"),
                                      min = min(df$year), 
                                      max = max(df$year), 
                                      value = c(2000, 2007)),
                          uiOutput("combo_pais")
                        ),
                        mainPanel(
                          tabsetPanel(
                            tabPanel("TAB1", plotOutput("plot_lifeexp_pop")),
                            tabPanel("TAB2", tableOutput("table_country"))
                          ) )
                      )
             ),
             tabPanel("Más info",
                      h2("Podes agregar más cosas acá"))
  )
)

server <- function(input, output, session) {
  
  output$combo_pais <- renderUI({
    selectInput(inputId = 'output_pais', 
                label = "Selecciona el pais", 
                choices = unique(df[df$continent == input$input_continente, 'country']),
                selected = unique(df[df$continent == input$input_continente, 'country'])[1]
    )
  })
  
  df_filtrado <- reactive({
    df_nuevo <- df[df$year >= input$input_fecha[1] & df$year <= input$input_fecha[2] &
                     df$country == input$output_pais, ]
    df_nuevo
  })
  
  output$plot_lifeexp_pop <- renderPlot({
    ggplot(df_filtrado(), aes(x = lifeExp, y = pop)) +
      geom_point(size=6, color ='red') +
      geom_line(color='#3F5866') +
      labs (x='Expectativa de vida', y='Población',
            title='Gráfico de Población',
            caption='Gapminder')
  })
  
  output$table_country <- renderTable({
    head(df_filtrado())
  })
}

shinyApp(ui, server)