options(shiny.reactlog=TRUE)
library(shiny)
library(ggplot2)
library(gapminder)
library(shinythemes)

rm(list=ls())

df=gapminder


ui <- fluidPage(
  themeSelector(),
  #theme = shinytheme("darkly"),
  titlePanel('ANALISIS DE POBLACION'),
  sidebarLayout(
    sidebarPanel(
      radioButtons(inputId='input_continente', 
                   label='seleccion de continente', 
                   choices = unique(df$continent),
                   selected = NULL),
      
      checkboxInput(inputId='input_masinfo', 
                    label=strong('Mas info'), 
                    value = FALSE, width = NULL),
      
      sliderInput("input_fecha", label = h3("seleccion del periodo"),
                  min = min(df$year),
                  max = max(df$year), 
                  value = c(1990, 2007)),
      
      
      uiOutput("combo_pais"),
      helpText('Observaciones:',
               "Un extracto de los datos disponibles en Gapminder.org. 
                Para cada uno de los 142 países, el paquete proporciona
                valores para la esperanza de vida, el PIB per capita y 
               la poblaci?n, cada cinco anos, desde 1952 hasta 2007.")
      
      
    ),
    mainPanel(
      plotOutput('output_g1', click = "plot_click"),
      verbatimTextOutput("output_coor"),
      textOutput("output_masinfo"),
      br(),
      verbatimTextOutput('summary')
      
    )
  )
  
)


server <- function(input, output) {
  df.filt <- reactive({
    df.filt=df[df$country==input$output_pais & df$year>=input$input_fecha[1] 
               & df$year<=input$input_fecha[2],]
    df.filt
  })
  
  output$combo_pais <- renderUI({
    selectInput(inputId="output_pais", h3("Seleccionar el pais"), 
                choices = unique(df[df$continent==input$input_continente,'country']), 
                selected = 1
    )
  })
  
  
  output$output_g1=renderPlot({
    ggplot(df.filt(),aes(x=lifeExp,y=pop,color=ifelse(lifeExp<60, '#C70039', '#477F56')))+
      geom_point(size=6,show.legend = F)+
      geom_line(color='#3F5866')+
      labs(x='Expectativa de vida', y='poblacion',
           title='Grafico de poblacion mundial',
           caption='informacion obtenida de la libreria gapminder' )
    
    
  })
  
  output$output_coor <- renderText({
    paste0("Coordenadas:","\nx=", input$plot_click$x, "\ny=", input$plot_click$y)
  })
  
  output$output_masinfo <- renderText({
    
    if(input$input_masinfo==TRUE){
      #df1= df[df$country==input$input_pais & df$year>=input$input_fecha[1] 
      #                & df$year<=input$input_fecha[2],]
      
      prom=mean(df.filt()$gdpPercap)
      paste0('GdpPercap primedio es: ',round(prom,2))
    }
    
  })
  
  
  output$summary=renderPrint({
    summary(df.filt()[,c('lifeExp','pop')])
  })
  
  
}

shinyApp(ui = ui, server = server)
