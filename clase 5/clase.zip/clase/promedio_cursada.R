promedio_cursada <- function(calificaciones) { 
  #Indico el nombre de la función y paso un sólo parámetro, las calificaciones, que van a ser un vector numérico
  
  media <- mean(calificaciones) #calculo la media de las calificaciones
  
  texto <- paste0("Calificación: ", media, ", ") # me genero una concatenación de strings donde voy a pegar la calificación
  
  if(media >= 6) {
    print(paste0(texto, "aprobado"))
  } else {
    print(paste0(texto, "reprobado")) 
    #evalúo si la media de calificaciones calculada más arriba es mayor a 6, si da TRUE imprime la string que ya teníamos armada indicando que está aprobado, y reprobado si la media es menor a 6
  }
}