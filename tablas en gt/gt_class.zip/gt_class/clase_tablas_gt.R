## Cargar las librerias:
library(gapminder)
library(dplyr)
library(scales)
library(gt)
library(gtExtras)
library(paletteer)
library(ggplot2)

rm(list = ls())

## Se va a usar el dataset de gapminder. En principio para el año 2007:
data = gapminder

data <- data[data$year == 2007, ]

#################################################################
################## Mi primera tabla en GT #######################
#################################################################

head(data) %>% 
  gt() %>%
  # tab_spanner(
  #   label = "Métricas",
  #   columns = c(lifeExp, pop, gdpPercap)
  # )

##################################################################
################## Summary table en GT ###########################
##################################################################

gapminder %>%
  gt_plt_summary()


#################################################################
#### La tabla más sencilla posible con titulo, nota al pie ######
####      y reemplazar nombre de columnas y esconderlas    ######
#################################################################

tabla_gt <- data %>%
    gt() %>%
    #Esconder las preguntas que no nos importan
    cols_hide(columns = c(continent, year, pop, lifeExp)) %>% 
    #Renombrar columnas
    cols_label(country = "País",
               #pop  = "Población",
               #lifeExp = "Expectativa de vida"
               gdpPercap = "PBI (per cápita)") %>% 
    #Agregar título a la tabla
    #La función `md` permite escribir el titulo con la sintaxis de markdown que permite HTML
    tab_header(title = md("Comparación de métricas para el <italic> año 2007 </italic> <strong> por país </strong>")) %>% 
    #agregar la fuente
    tab_source_note(source_note = "Data: Paquete Gapmider en R") 


#################################################################
#### Cambindo cuestiones de estilo  #############################
#################################################################


tabla_gt <- tabla_gt %>%  
  #Aplicar nuevo estilo a las columnas
  tab_style(
    locations = cells_column_labels(columns = everything()),
    style     = list(
      #Generar una linea gris abajo más pequeña
      cell_borders(sides = "bottom", weight = px(3)),
      #Hacer que el texto este en negrita
      cell_text(weight = "bold")
    )
  ) %>% 
  #Aplicar nuevo estilo al titulo
  tab_style(
    locations = cells_title(groups = "title"),
    style     = list(
      cell_text(weight = "bold", size = 24)
    )
  )

#################################################################
#### Cambiarle el fondo según un valor numérico (gdpPercap) #####
#################################################################

min_gdp <- min(data$gdpPercap)
max_gdp <- max(data$gdpPercap)
gdp_paleta <- col_numeric(c("#FEF0D9", "#990000"), domain = c(min_gdp, max_gdp), alpha = 0.75)

tabla_gt <- tabla_gt %>% 
  data_color(columns = c(gdpPercap),
             colors = gdp_paleta)
tabla_gt <- tabla_gt %>% 
  opt_all_caps() %>% 
  opt_table_font(
    font = list(
      google_font("Chivo"),
      default_fonts()
    )
  ) %>%
  cols_width(c(gdpPercap) ~ px(150),
             c(country) ~ px(400)) %>% 
  tab_options(
    column_labels.border.top.width = px(3),
    column_labels.border.top.color = "transparent",
    table.border.top.color = "transparent",
    table.border.bottom.color = "transparent",
    data_row.padding = px(3),
    source_notes.font.size = 12,
    heading.align = "left"
  )

tabla_gt
#############################################################
##### Cambiarle el fondo a una categoria (country) ##########
#####            en base al continente             ##########
#############################################################


colors <- paletteer::paletteer_d("RColorBrewer::Set1", length(unique(data$continent)))

# Crear un dataframe con los colores asignados
color_df <- data.frame(continent = unique(data$continent), color = colors)

continent_colors <- function(continent) {
  colors <- c(
    "Asia" = "#BEBADA",
    "Africa" = "#FB8072",
    "Europe" = "#80B1D3",
    "Americas" = "#8DD3C7",
    "Oceania" = "#FFFFB3"
  )
  return(colors[continent])
}

table <- data %>%
  gt(groupname_col = "continent") %>%
  #Esconder las preguntas que no nos importan
  cols_hide(columns = c(continent, year, pop, lifeExp)) %>% 
  #Renombrar columnas
  cols_label(country = "País",
             pop  = "Población",
             gdpPercap = "PBI (per cápita)",
             lifeExp = "Expectativa de vida") %>% 
  #Agregar título a la tabla
  #La función `md` permite escribir el titulo con la sintaxis de markdown que permite HTML
  tab_header(title = md("Comparación de métricas para el <italic> año 2007 </italic> <strong> por país </strong>")) %>% 
  #agregar la fuente
  tab_source_note(source_note = "Data: Paquete Gapmider en R") %>%
  tab_style(
    locations = cells_column_labels(columns = everything()),
    style     = list(
      #Generar una linea gris abajo más pequeña
      cell_borders(sides = "bottom", weight = px(3)),
      #Hacer que el texto este en negrita
      cell_text(weight = "bold")
    )
  ) %>% 
  #Aplicar nuevo estilo al titulo
  tab_style(
    locations = cells_title(groups = "title"),
    style     = list(
      cell_text(weight = "bold", size = 24)
    )
  )  %>% 
  data_color(columns = c(gdpPercap),
             colors = gdp_paleta) %>%
    data_color(
      columns = vars(country),
      colors = purrr::map_chr(data$continent, continent_colors)
    )

table

#############################################################
###### Cambiarle el color a la categoria (country) ##########
######           en base al continente             ##########
#############################################################

continent_colors2 <- function(continent) {
  colors <- c(
    "Asia" = "#5744db",
    "Africa" = "#fc5947",
    "Europe" = "#1682cc",
    "Americas" = "#13cfae",
    "Oceania" = "#f7f70f"
  )
  return(colors[continent])
}

styles <- data %>%
  mutate(color = continent_colors2(continent)) %>%
  select(country, color)

for (i in 1:nrow(styles)) {
  table <- table %>%
    tab_style(
      style = cell_text(color = styles$color[i]),
      locations = cells_body(
        columns = vars(country),
        rows = country == styles$country[i]
      )
    )
}

#############################################################
###########    Seguimos cambiando la fuente y      ##########
###########        las cuestiones de estilo        ##########
#############################################################

table  %>%
  opt_all_caps() %>% 
   opt_table_font(
    font = list(
      google_font("Chivo"),
      default_fonts()
    )
  ) %>%
  cols_width(c(gdpPercap) ~ px(150),
             c(country) ~ px(400)) %>% 
  tab_options(
    column_labels.border.top.width = px(3),
    column_labels.border.top.color = "transparent",
    table.border.top.color = "transparent",
    table.border.bottom.color = "transparent",
    data_row.padding = px(3),
    source_notes.font.size = 12,
    heading.align = "left"
  )

##############################################################
############## Agregarle un plot desde GT ####################
##############################################################


data_sparkline <- gapminder %>%
    group_by(continent, country) %>%
    summarize(
      pop_list = list(pop)) %>%
    left_join(data)
  
tabla_gt <- data_sparkline %>%
  gt() %>%
  gtExtras::gt_plt_sparkline(pop_list)

tabla_gt

##############################################################
############## Agregarle un plot desde GGPLOT2 ###############
##############################################################

# 1. Generamos el plot:

#i = "Argentina"

for(i in unique(gapminder$country)){
  
  message("----", i, "----")
  
  p <- gapminder %>%
    filter(country == i) %>%
    ggplot() +
    geom_line(aes(x=year, y = lifeExp),
              color = as.character(unique(styles[styles$country ==i, "color"])[1]),
              size = 2) +
    geom_point(aes(x=year, y = lifeExp), 
               color = as.character(unique(styles[styles$country ==i, "color"])[1]), size = 5) +
    theme_minimal() +
    labs( x = "Año", y = "Expectativa de vida")  
  
  png(paste0("C:/Users/User/Documents/GitHub/ejercicios_database_gcba/tablas en gt/img/",i,".png"))
  print(p)
  dev.off()
  
}

# 2. Incorporamos los plots desde nuestro archivo local a la tabla:

#image_path <- "C:/Users/User/Documents/GitHub/ejercicios_database_gcba/tablas en gt/img/"
image_github <- "https://github.com/guadag12/ejercicios_database_gcba/raw/main/tablas%20en%20gt/img/"

data_sparkline %>%
  mutate(image_expectativa_vida = paste0(country)) %>%
  gt() %>%
  gtExtras::gt_plt_sparkline(pop_list) %>%
    text_transform(
      locations = cells_body(vars(image_expectativa_vida)),
      fn = function(x) {
        paste0(
          "<img src='", image_github, x, ".png' style='height:50px width:100px;'>"
        )
      }
    )

#################################################################
######################### Unamos todo!  #########################
#################################################################

data_sparkline <- gapminder %>%
  group_by(continent, country) %>%
  summarize(
    pop_list = list(pop)) %>%
  left_join(data[data$year == "2007", c("country", "gdpPercap") ]) %>%
  mutate(image_expectativa_vida = paste0(country))

tabla_definitiva <- data_sparkline %>%
  select(continent, country, gdpPercap, pop_list, image_expectativa_vida) %>%
  gt() %>%
  
  ############### CUESTIONES DE ESTILO DE TITULO Y COLUMNAS ########
  tab_spanner(
    label = "Métricas",
    columns = c(gdpPercap, pop_list, image_expectativa_vida)
  ) %>%
  cols_label(country = "País",
             pop_list  = "Población",
             image_expectativa_vida = "Expectativa de vida",
             gdpPercap = "PBI (per cápita 2007)") %>% 
  tab_header(title = md("Comparación de métricas para el <em> año 2007 </em> <strong> por país </strong>")) %>% 
  tab_source_note(source_note = "Data: Paquete Gapmider en R")  %>%
  
  ############### CAMBIAN COLORES DE CELDAS Y TEXTO ########
  data_color(columns = c(gdpPercap), colors = gdp_paleta) %>%
  data_color( columns = c(country), colors = purrr::map_chr(data$continent, continent_colors) ) %>%
  
  
  ############### Agregan los plots de evolución ########
  gtExtras::gt_plt_sparkline(pop_list) %>%
  text_transform(
    locations = cells_body(c(image_expectativa_vida)),
    fn = function(x) {
      paste0(
        "<img src='", image_github, x, ".png' style='height:50px; width:150px;' >"
      )
    }
  ) %>%
  ######## AGREGAR CUESTIONES DE CONFIGURACION Y LETRAS    #####
   opt_all_caps() %>% 
    opt_table_font(
      font = list(
        google_font("Chivo"),
        default_fonts()
      )
    ) %>%
    cols_width(c(gdpPercap) ~ px(150), c(country) ~ px(400)) %>% 
    tab_options(
      column_labels.border.top.width = px(3),
      column_labels.border.top.color = "transparent",
      table.border.top.color = "transparent",
      table.border.bottom.color = "transparent",
      data_row.padding = px(3),
      source_notes.font.size = 12,
      heading.align = "left"
    ) %>%
  tab_style( locations = cells_column_labels(columns = everything()),
    style     = list(
      cell_borders(sides = "bottom", weight = px(3)),
      cell_text(weight = "bold")
    )
  ) %>% 
  tab_style( locations = cells_title(groups = "title"),
     style = list(
      cell_text(weight = "bold", size = 24)
    )
  ) 

tabla_definitiva

##################################################################
########## Guardar la tabla  en diferentes formatos ##############
##################################################################

library(webshot2)

tabla_save <- head(data) %>% gt()
gtsave(data = tabla_save, filename = "C:/Users/User/Documents/GitHub/ejercicios_database_gcba/tablas en gt/tab_1.png")
gtsave(data = tabla_save, filename = "C:/Users/User/Documents/GitHub/ejercicios_database_gcba/tablas en gt/tab_1.pdf")
gtsave(data = tabla_save, filename = "C:/Users/User/Documents/GitHub/ejercicios_database_gcba/tablas en gt/tab_1.html")
gtsave(data = tabla_save, filename = "C:/Users/User/Documents/GitHub/ejercicios_database_gcba/tablas en gt/tab_1.docx")
gtsave(tabla_save, "C:/Users/User/Documents/GitHub/ejercicios_database_gcba/tablas en gt/tab_1.rtf")


#Más info: https://gt.rstudio.com/reference/gtsave.html

##################################################################
####### Algunas otras fuentes de consulta ########################
##################################################################


# https://r-graph-gallery.com/368-plotting-in-cells-with-gtextras.html
# https://jthomasmock.github.io/gtExtras/articles/plots-in-gt.html
# https://karbartolome-blog.netlify.app/posts/tablas-subte/
# https://gt.rstudio.com/reference/local_image.html
# https://rladiesba.netlify.app/post/tablasgtpost/
# https://gt.rstudio.com/reference/fmt_image.html

